package id.ac.ub.papb.recycler1;

public class Mahasiswa {
    String nim;
    String nama;

    // Constructor baru untuk inisialisasi cepat
    public Mahasiswa(String nim, String nama) {
        this.nim = nim;
        this.nama = nama;
    }

    // Constructor kosong tetap ada
    public Mahasiswa() {
    }
}
